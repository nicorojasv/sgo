
$(document).ready(function() {
$('#tablaAsistenciaEnjoy').stacktable();
});
