$(document).ready(function(){
  $("#example1").dataTable({
    scrollY:        "500px",
    scrollX:        false,
    scrollCollapse: false,
    paging:         false,
    fixedColumns:   {
        leftColumns: 1,
        rightColumns: 1
    }
  });
  $("#example2").dataTable({
    scrollY:        "500px",
    scrollX:        false,
    scrollCollapse: false,
    paging:         false,
    fixedColumns:   {
        leftColumns: 1,
        rightColumns: 1
    }
  });
  $("#example3").dataTable({
    scrollY:        "500px",
    scrollX:        false,
    scrollCollapse: false,
    paging:         false,
    fixedColumns:   {
        leftColumns: 1,
        rightColumns: 1
    }
  });
});