$(document).ready(function (){
	$('.fecha_ingreso_esperado').datepicker({
		format: 'yyyy-mm-dd',
	});
});