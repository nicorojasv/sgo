$(document).ready(function () {
  	$('#fecha_inicio').datepicker({
    	format: 'yyyy-mm-dd',
	});
	$('#fecha_termino').datepicker({
    	format: 'yyyy-mm-dd',
	});
});