$(document).ready(function () {
  	$('#fecha_cobro_inicio').datepicker({
    	format: 'yyyy-mm-dd',
	});

	$('#fecha_cobro_termino').datepicker({
    	format: 'yyyy-mm-dd',
	});

	$('#fecha_eval_inicio').datepicker({
    	format: 'yyyy-mm-dd',
	});

	$('#fecha_eval_termino').datepicker({
    	format: 'yyyy-mm-dd',
	});


});