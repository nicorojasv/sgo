$(document).ready(function(){
	$('#dp3').datepicker();
});