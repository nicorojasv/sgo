$(document).ready(function () {
  $('#datepicker').datepicker({
    format: 'yyyy-mm-dd',
  });

  $('#datepicker2').datepicker({
    format: 'yyyy-mm-dd',
  });
});