<li><a href="<?php echo base_url() ?>usuarios/home"><i class="fa fa-home"></i> <span class="title"> Inicio </span></a></li>
<li><a href="<?php echo base_url() ?>abastecimiento"><i class="fa fa-user"></i> <span class="title"> Abastecimiento </span></a></li>

<li><a href="javascript:void(0)"><i class="fa fa-user"></i> <span class="title"> Revision Examenes </span></a>
	<ul class="sub-menu">
		<li><a href="<?php echo base_url() ?>est/trabajadores/solicitudes_revision_examenes"><i class="fa fa-user"></i> <span class="title"> Solicitudes Pendientes </span></a></li>
		<li><a href="<?php echo base_url() ?>est/trabajadores/listado_solicitudes_completas_sre"><i class="fa fa-user"></i> <span class="title"> Solicitudes Realizadas </span></a></li>
	</ul>
</li>
<li><a href="<?php echo base_url() ?>est/trabajadores/contratos_y_anexos"><i class="fa fa-bullhorn"></i> <span class="title"> Informe Contratos y Anexos </span></a></li>
<li><a href="<?php echo base_url() ?>est/trabajadores/base_datos_evaluaciones_propios_sin_ccosto"><i class="fa fa-home"></i> <span class="title"> Visualizacion Evaluacion Propios sin Centro de Costo </span></a></li>
<li><a href="<?php echo base_url() ?>est/trabajadores/buscar_js"><i class="fa fa-user"></i> <span class="title"> Listado Trabajadores </span></a></li>