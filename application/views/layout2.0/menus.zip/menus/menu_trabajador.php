<li class="nav link"><a href="<?php echo base_url() ?>trabajador" class="item"> Inicio </a></li>
<li class="nav link"><a href="<?php echo base_url() ?>trabajador/evaluaciones/informe" class="item"> Evaluaciones </a></li>
<li class="nav link"><a href="<?php echo base_url() ?>trabajador/requerimiento/historial" class="item"> Trabajos </a></li>
<li class="nav link"><a href="<?php echo base_url() ?>trabajador/ofertas" class="item"> Ofertas </a></li>
<li class="nav link"><a href="<?php echo base_url() ?>trabajador/noticias_laborales" class="item"> Noticias Laborales </a><div class="notify">new</div></li>
<!--<li class="nav link"><a href="<?php echo base_url() ?>trabajador/publicaciones" class="item"> Publicaciones </a></li>-->