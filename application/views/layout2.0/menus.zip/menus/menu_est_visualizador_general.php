<li><a href="<?php echo base_url() ?>usuarios/home"><i class="fa fa-home"></i> <span class="title"> Inicio </span></a></li>
<li><a href="<?php echo base_url() ?>abastecimiento"><i class="fa fa-user"></i> <span class="title"> Abastecimiento </span></a></li>

<li><a href="<?php echo base_url() ?>usuarios/perfil/index"><i class="fa fa-user"></i> <span class="title"> Perfil </span></a></li>
<li><a href="<?php echo base_url() ?>est/trabajadores/buscar_js"><i class="fa fa-user"></i> <span class="title"> Trabajadores </span></a></li>
<li><a href="javascript:void(0)" ><i class="fa fa-gears"></i> <span class="title"> Requerimientos </span><i class="icon-arrow"></i></a>
	<ul class="sub-menu">
		<li><a href="<?php echo base_url() ?>est/requerimiento/listado"><i class="fa fa-bullhorn"></i> <span class="title"> Listado de Requerimientos </span></a></li>
	</ul>
</li>
<li><a href="<?php echo base_url() ?>est/trabajadores/contratos_y_anexos"><i class="fa fa-bullhorn"></i> <span class="title"> Informe Contratos y Anexos </span></a>