<?php 
$activo = $this->session->userdata('activo');
		  $this->session->unset_userdata('activo');
		if (!empty($activo)) {
			$a = explode("-", $activo);
			$menu = $a[0];
			$nombre = $a[1];
			$b = explode('.', $activo);
			$numMenu = $b[0];
		}
	
?>
<style type="text/css">
	.AramarkColor:hover {
        background: #ca7677c2 !important;
}
	.EnjoyColor:hover {
        background: #b18957c7 !important;
}
	.blueColor:hover {
        background: #728bd4bd !important;
}
	.AraucoColor:hover {
        background: #427617c4 !important;
}
	.Marina:hover {
		background: #fdcc3cab !important;
}

</style>
<li>
	<a href="javascript:void(0)"><i class="fa fa-user"></i> <span class="title" style="color: #44790f"> ARAUCO </span></a>

	<ul class="sub-menu" class="sub-menu" <?php if(isset($menu)){if($menu == '1.6')echo "style='display: block;'"; }?>>
	<li class="clickButtonMenu <?php if(isset($nombre)){ if($nombre === 'home')echo "active"; }?> " data="1.1-home">
		<a class="AraucoColor" href="<?php echo base_url() ?>usuarios/home"><i class="fa fa-home"></i> <span class="title"> Inicio </span></a>
	</li>

	<li class="clickButtonMenu <?php if(isset($nombre)){ if($nombre === 'buscar_js')echo "active"; }?> " data="1.2-buscar_js">
		<a class="AraucoColor" href="<?php echo base_url() ?>est/trabajadores/buscar_js"><i class="fa fa-user"></i> <span class="title"> Listado Trabajadores </span></a>
	</li>

	<li class="clickButtonMenu <?php if(isset($nombre)){ if($nombre === 'listado')echo "active"; }?> " data="1.3-listado">
		<a class="AraucoColor" href="<?php echo base_url() ?>est/requerimiento/listado"><i class="fa fa-bullhorn"></i> <span class="title"> Listado de Requerimientos </span></a>
	</li>

	<!--<li class="clickButtonMenu <?php if(isset($nombre)){ if($nombre === 'con_est')echo "active"; }?> " data="1.4-con_est">
		<a class="AraucoColor" href="<?php echo base_url() ?>est/trabajadores/contratos_y_anexos_est"><i class="fa fa-bullhorn"></i> <span class="title"> Informe Contratos y Anexos </span>
		</a>
	</li>-->

	<li>
		<a class="AraucoColor" href="javascript:void(0)"><i class="fa fa-user"></i> <span class="title"> Solicitudes de Contratos Integra </span></a>
		<ul class="sub-menu" <?php if(isset($menu)){if($menu == '1.5')echo "style='display: block;'"; }?>>
			<li  class="clickButtonMenu <?php if(isset($nombre)){ if($nombre === 'est_sol_pend')echo "active"; }?> " data="1.5-est_sol_pend">
				<a class="AraucoColor" href="<?php echo base_url() ?>est/contratos/solicitudes_pendientes"><i class="fa fa-user"></i> <span class="title"> Solicitudes Pendientes </span></a>
			</li>
			<li  class="clickButtonMenu <?php if(isset($nombre)){ if($nombre === 'est_sol_comp')echo "active"; }?> " data="1.5-est_sol_comp">
				<a class="AraucoColor" href="<?php echo base_url() ?>est/contratos/solicitudes_completas"><i class="fa fa-user"></i> <span class="title"> Solicitudes Completas </span></a>
			</li>
		</ul>
	</li>

	<li>
		<a class="AraucoColor" href="javascript:void(0)"><i class="fa fa-user"></i> <span class="title"> Solicitudes de Anexos Arauco </span></a>
			<ul class="sub-menu" <?php if(isset($menu)){if($menu == '1.16')echo "style='display: block;'"; }?> >
				<li class=" clickButtonMenu <?php if(isset($nombre)){ if($nombre === 'est_cont_soli_pendiAnexo')echo "active"; }?> " data="1.16-est_cont_soli_pendiAnexo">
					<a class="AraucoColor" href="<?php echo base_url() ?>est/contratos/solicitudes_pendientes_anexo"><i class="fa fa-user"></i> <span class="title"> Solicitudes Pendientes </span></a>
				</li>
				<li class=" clickButtonMenu <?php if(isset($nombre)){ if($nombre === 'est_solicitudes_completasAnexo')echo "active"; }?> " data="1.16-est_solicitudes_completasAnexo">
					<a class="AraucoColor" href="<?php echo base_url() ?>est/contratos/solicitudes_completas_anexo"><i class="fa fa-user"></i> <span class="title"> Solicitudes Completas </span></a>
				</li>
			</ul>
		</li>
	</ul>
</li>

<li>
	<a href="javascript:void(0)"><i class="fa fa-user"></i> <span class="title" style="color: blue"> BLUE </span></a>
	<ul class="sub-menu" class="sub-menu" <?php if(isset($menu)){if($menu == '1.6')echo "style='display: block;'"; }?>>
		<li class="clickButtonMenu <?php if(isset($nombre)){ if($nombre === 'blue_sol_pen')echo "active"; }?> " data="1.6-blue_sol_pen">
			<a class="blueColor" href="<?php echo base_url() ?>est/contratos_log/solicitudes_pendientes"><i class="fa fa-user"></i> <span class="title"> Solicitudes Pendientes </span></a>
		</li>
		<li class="clickButtonMenu <?php if(isset($nombre)){ if($nombre === 'blue_sol_comp')echo "active"; }?> " data="1.6-blue_sol_comp">
			<a class="blueColor" href="<?php echo base_url() ?>est/contratos_log/solicitudes_completas"><i class="fa fa-user"></i> <span class="title"> Solicitudes Completas </span></a>
		</li>
	</ul>
</li>

<li>
	<a href="javascript:void(0)"><i class="fa fa-user"></i> <span class="title" style="color: #d4812f"> ENJOY </span></a>
	<ul class="sub-menu" class="sub-menu" <?php if(isset($menu)){if($menu == '1.7')echo "style='display: block;'"; }?>>
		<li class="clickButtonMenu <?php if(isset($nombre)){ if($nombre === 'enjoy_sol_pen')echo "active"; }?> " data="1.7-enjoy_sol_pen">
			<a class="EnjoyColor" href="<?php echo base_url() ?>enjoy/contratos/solicitudes_pendientes"><i class="fa fa-user"></i> <span class="title"> Solicitudes Pendientes </span></a>
		</li>
		<li class="clickButtonMenu <?php if(isset($nombre)){ if($nombre === 'enjoy_sol_comp')echo "active"; }?> " data="1.7-enjoy_sol_comp">
			<a class="EnjoyColor" href="<?php echo base_url() ?>enjoy/contratos/solicitudes_completas"><i class="fa fa-user"></i> <span class="title"> Solicitudes Completas </span></a>
		</li>
		<li class=" clickButtonMenu <?php if(isset($nombre)){ if($nombre === 'enjoy_sol_pen_baj')echo "active"; }?> " data="1.7-enjoy_sol_pen_baj">
			<a class="EnjoyColor" href="<?php echo base_url() ?>enjoy/contratos/solicitudes_pendientes_baja"><i class="fa fa-user"></i> <span class="title"> Solicitud en proceso de baja </span></a>
		</li>
		<?php if ($this->session->userdata('id')==24) {
			
		?>
		<li class=" clickButtonMenu <?php if(isset($nombre)){ if($nombre === 'enjoy_listado')echo "active"; }?> " data="1.7-enjoy_listado">
			<a href="<?php echo base_url() ?>enjoy/requerimientos/listado"><i class="fa fa-home"></i> <span class="title"> Requerimientos </span></a>
		</li>
	<?php }?>
		<li class=" clickButtonMenu <?php if(isset($nombre)){ if($nombre === 'enjoy_sol_compl_baj')echo "active"; }?> " data="1.7-enjoy_sol_compl_baj">
			<a class="EnjoyColor" href="<?php echo base_url() ?>enjoy/contratos/solicitudes_completas_baja"><i class="fa fa-user"></i> <span class="title"> Solicitudes Bajadas </span></a>
		</li>
	</ul>
</li>
<li  <?php if(isset($numMenu)){if ($numMenu == 4)echo "class='open'"; }?>>
	<a href="javascript:void(0)"><i class="fa fa-home"></i> <span class="title" style="color: #eb3b34"> ARAMARK </span></a>
	<ul class="sub-menu" <?php if(isset($numMenu)){if ($numMenu == 4)echo "style='display: block;'"; }?>>
		<li>		
				<!--4.41-->
				<li  class=" clickButtonMenu <?php if(isset($nombre)){ if($nombre === 'aramark_sol_pendie')echo "active"; }?> " data="4.41-aramark_sol_pendie">
					<a class="AramarkColor" href="<?php echo base_url() ?>aramark/contratos/solicitudes_pendientes"><i class="fa fa-user"></i> <span class="title"> Solicitudes Pendientes </span></a>
				</li>
				<!--4.41-->
				<li class=" clickButtonMenu <?php if(isset($nombre)){ if($nombre === 'aramark_sol_compl')echo "active"; }?> " data="4.41-aramark_sol_compl">
					<a class="AramarkColor" href="<?php echo base_url() ?>aramark/contratos/solicitudes_completas"><i class="fa fa-user"></i> <span class="title"> Solicitudes Completas </span></a>
				</li>
				<li class=" clickButtonMenu <?php if(isset($nombre)){ if($nombre === 'aramark_sol_pen_baj')echo "active"; }?> " data="4.41-aramark_sol_pen_baj">
					<a class="AramarkColor" href="<?php echo base_url() ?>aramark/contratos/solicitudes_pendientes_baja"><i class="fa fa-user"></i> <span class="title"> Solicitud en proceso de baja </span></a>
				</li>
				<li class=" clickButtonMenu <?php if(isset($nombre)){ if($nombre === 'aramark_sol_compl_baj')echo "active"; }?> " data="4.41-aramark_sol_compl_baj">
					<a class="AramarkColor" href="<?php echo base_url() ?>aramark/contratos/solicitudes_completas_baja"><i class="fa fa-user"></i> <span class="title"> Solicitudes Bajadas </span></a>
				</li>

		</li>
	</ul>
</li>
<li  <?php if(isset($numMenu)){if ($numMenu == 5)echo "class='open'"; }?>>
	<a href="javascript:void(0)"><i class="fa fa-home"></i> <span class="title" style="color: #fdcc3c"> Marina Del Sol </span></a>
	<ul class="sub-menu" <?php if(isset($numMenu)){if ($numMenu == 5)echo "style='display: block;'"; }?>>
		<li>		
				<li  class=" clickButtonMenu <?php if(isset($nombre)){ if($nombre === 'marina_sol_pendie')echo "active"; }?> " data="5.41-marina_sol_pendie">
					<a class="marinaColor" href="<?php echo base_url() ?>marina/contratos/solicitudes_pendientes"><i class="fa fa-user"></i> <span class="title"> Solicitudes Pendientes </span></a>
				</li>
				<!--5.41-->
				<li class=" clickButtonMenu <?php if(isset($nombre)){ if($nombre === 'marina_sol_compl')echo "active"; }?> " data="5.41-marina_sol_compl">
					<a class="marinaColor" href="<?php echo base_url() ?>marina/contratos/solicitudes_completas"><i class="fa fa-user"></i> <span class="title"> Solicitudes Completas </span></a>
				</li>
				<li class=" clickButtonMenu <?php if(isset($nombre)){ if($nombre === 'marina_sol_pen_baj')echo "active"; }?> " data="5.41-marina_sol_pen_baj">
					<a class="marinaColor" href="<?php echo base_url() ?>marina/contratos/solicitudes_pendientes_baja"><i class="fa fa-user"></i> <span class="title"> Solicitud en proceso de baja </span></a>
				</li>
				<li class=" clickButtonMenu <?php if(isset($nombre)){ if($nombre === 'marina_sol_compl_baj')echo "active"; }?> " data="5.41-marina_sol_compl_baj">
					<a class="marinaColor" href="<?php echo base_url() ?>marina/contratos/solicitudes_completas_baja"><i class="fa fa-user"></i> <span class="title"> Solicitudes Bajadas </span></a>
				</li>
				
			<?php if ($this->session->userdata('id')==24) { ?>
				<li class=" clickButtonMenu <?php if(isset($nombre)){ if($nombre === 'marina_listado')echo "active"; }?> " data="5.41-marina_listado">
					<a href="<?php echo base_url() ?>marina/requerimientos/listado"><i class="fa fa-home"></i> <span class="title"> Requerimientos </span></a>
				</li>
				
			<?php }?>
		</li>
		<li><a href="<?php echo base_url() ?>est/requerimiento/generar_dt"><i class="fa fa-home"></i> <span class="title">Generar DT </span></a> <span class="badge"> NEW</span></li>
	</ul>
</li>