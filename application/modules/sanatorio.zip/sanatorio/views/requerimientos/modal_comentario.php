<textarea rows="5" class="comentario" data-id="<?php echo $id ?>" style="width: 515px;"><?php echo $comentario ?></textarea>
     