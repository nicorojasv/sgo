<div class="panel panel-white"> 
	<label>Listado Personaaa</label>
	<?php 
		foreach ($listado as $key) {
			
		}

	?>
	<table id=”tabla1″ class=”table stacktable” border=”0″>
		<tr>
		<th>…asadasd</th>
		<th>…asdads</th>
		<th>asdsa…</th>
		</tr>
		<tr>
		<td>…</td>
		<td>…</td>
		<td>…</td>
		</tr>
		<tr>
		<td>…</td>
		<td>…</td>
		<td>…</td>
		<td>…</td>
		</tr>
		</table>
</div>